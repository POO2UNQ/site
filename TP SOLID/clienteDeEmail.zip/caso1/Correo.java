package openClosedPrinciple.caso1;

public class Correo {

	public Correo(String asunto, String destinatario, String cuerpo) {
		// TODO Auto-generated constructor stub
	}

}
