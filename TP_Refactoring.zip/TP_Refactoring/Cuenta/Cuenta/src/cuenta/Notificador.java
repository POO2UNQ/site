package cuenta;

public interface Notificador {
	void notificarNuevoSaldoACliente(CuentaBancaria cuentaBancaria);

}
