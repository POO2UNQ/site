package cuenta;

public interface HistorialMovimientos {

	void registrarMovimiento(String descripcion, Integer monto);

}
